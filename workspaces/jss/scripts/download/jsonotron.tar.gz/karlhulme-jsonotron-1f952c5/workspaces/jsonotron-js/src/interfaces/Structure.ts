import { Field } from './Field'

export type Structure = Record<string, Field>
